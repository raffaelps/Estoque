//
//  ViewController.h
//  Sistoque
//
//  Created by Leonardo on 21/09/13.
//  Copyright (c) 2013 Leonardo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)btnProduto:(id)sender;
- (IBAction)btnCategoria:(id)sender;
- (IBAction)btnRelatorio:(id)sender;
- (void)abrirJanela:(UIViewController *)tela;


@end
